# DAY1 首页高清图替换顺序

将这些图片上传到仓库后，按下面顺序替换首页对应段落：

1. `00-prologue.webp` → 序幕 / 首屏 Hero
2. `01-longing.webp` → 01 / 向往
3. `02-listening.webp` → 02 / 看见自己
4. `03-clarifying.webp` → 03 / 梳理关系
5. `04-building.webp` → 04 / 落地实施
6. `05-leaving.webp` → 05 / 设计师离开
7. `06-life-begins.webp` → 06 / 生活开始

建议上传目录：`assets/home-story/`
